-- Book Loan Data
INSERT INTO Book_loan VALUES
(1, 1, '2023-11-01', 14, '2023-11-15'),  -- Ahmed Khan borrows 'Moth Smoke'
(2, 2, '2023-11-05', 7, '2023-11-12'),   -- Fatima Ali borrows 'Home Fire'
(3, 3, '2023-10-20', 21, '2023-11-10'),  -- Muhammad Ahmed borrows 'A Case of Exploding Mangoes'
(4, 4, '2023-10-15', 10, '2023-10-25'),  -- Ayesha Raza borrows 'Ice Candy Man'
(5, 5, '2023-11-10', 14, '2023-11-24');  -- Bilal Siddiqui borrows 'Basti'
