-- Borrower Data
INSERT INTO Borrower VALUES
(1, 'Ahmed', 'Khan', 'ahmed.khan@email.com', '+92 300 1234567', '10 Lahore Street, Lahore'),
(2, 'Fatima', 'Ali', 'fatima.ali@email.com', '+92 321 2345678', '15 Lahore Avenue, Lahore'),
(3, 'Muhammad', 'Ahmed', 'muhammad.ahmed@email.com', '+92 333 3456789', '20 Lahore Lane, Lahore'),
(4, 'Ayesha', 'Raza', 'ayesha.raza@email.com', '+92 311 4567890', '25 Lahore Road, Lahore'),
(5, 'Bilal', 'Siddiqui', 'bilal.siddiqui@email.com', '+92 302 5678901', '30 Lahore Boulevard, Lahore');
