﻿namespace Book_Loan_Management_System
{
    partial class Update_Author_Name
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.addauthor_button = new System.Windows.Forms.Button();
            this.lastname_textbox = new System.Windows.Forms.TextBox();
            this.firstname_textbox = new System.Windows.Forms.TextBox();
            this.authorid_textbox = new System.Windows.Forms.TextBox();
            this.lastname_label = new System.Windows.Forms.Label();
            this.firstname_label = new System.Windows.Forms.Label();
            this.authorid_label = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // addauthor_button
            // 
            this.addauthor_button.BackColor = System.Drawing.Color.LightPink;
            this.addauthor_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addauthor_button.Location = new System.Drawing.Point(515, 195);
            this.addauthor_button.Name = "addauthor_button";
            this.addauthor_button.Size = new System.Drawing.Size(150, 43);
            this.addauthor_button.TabIndex = 33;
            this.addauthor_button.Text = "Update Name";
            this.addauthor_button.UseVisualStyleBackColor = false;
            // 
            // lastname_textbox
            // 
            this.lastname_textbox.Location = new System.Drawing.Point(332, 245);
            this.lastname_textbox.Name = "lastname_textbox";
            this.lastname_textbox.Size = new System.Drawing.Size(100, 20);
            this.lastname_textbox.TabIndex = 27;
            // 
            // firstname_textbox
            // 
            this.firstname_textbox.Location = new System.Drawing.Point(332, 200);
            this.firstname_textbox.Name = "firstname_textbox";
            this.firstname_textbox.Size = new System.Drawing.Size(100, 20);
            this.firstname_textbox.TabIndex = 26;
            // 
            // authorid_textbox
            // 
            this.authorid_textbox.Location = new System.Drawing.Point(332, 159);
            this.authorid_textbox.Name = "authorid_textbox";
            this.authorid_textbox.Size = new System.Drawing.Size(100, 20);
            this.authorid_textbox.TabIndex = 25;
            // 
            // lastname_label
            // 
            this.lastname_label.AutoSize = true;
            this.lastname_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastname_label.Location = new System.Drawing.Point(126, 243);
            this.lastname_label.Name = "lastname_label";
            this.lastname_label.Size = new System.Drawing.Size(89, 20);
            this.lastname_label.TabIndex = 19;
            this.lastname_label.Text = "Last_name";
            // 
            // firstname_label
            // 
            this.firstname_label.AutoSize = true;
            this.firstname_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstname_label.Location = new System.Drawing.Point(126, 200);
            this.firstname_label.Name = "firstname_label";
            this.firstname_label.Size = new System.Drawing.Size(89, 20);
            this.firstname_label.TabIndex = 18;
            this.firstname_label.Text = "First_name";
            // 
            // authorid_label
            // 
            this.authorid_label.AutoSize = true;
            this.authorid_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.authorid_label.Location = new System.Drawing.Point(126, 160);
            this.authorid_label.Name = "authorid_label";
            this.authorid_label.Size = new System.Drawing.Size(78, 20);
            this.authorid_label.TabIndex = 17;
            this.authorid_label.Text = "Author_id";
            // 
            // Update_Author_Name
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.addauthor_button);
            this.Controls.Add(this.lastname_textbox);
            this.Controls.Add(this.firstname_textbox);
            this.Controls.Add(this.authorid_textbox);
            this.Controls.Add(this.lastname_label);
            this.Controls.Add(this.firstname_label);
            this.Controls.Add(this.authorid_label);
            this.Name = "Update_Author_Name";
            this.Text = "Update_Author_Name";
            this.Load += new System.EventHandler(this.Update_Author_Name_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button addauthor_button;
        private System.Windows.Forms.TextBox lastname_textbox;
        private System.Windows.Forms.TextBox firstname_textbox;
        private System.Windows.Forms.TextBox authorid_textbox;
        private System.Windows.Forms.Label lastname_label;
        private System.Windows.Forms.Label firstname_label;
        private System.Windows.Forms.Label authorid_label;
    }
}