﻿namespace Book_Loan_Management_System
{
    partial class Books
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.displaycategory_button = new System.Windows.Forms.Button();
            this.bookloan_button = new System.Windows.Forms.Button();
            this.bookgridview = new System.Windows.Forms.DataGridView();
            this.displaybooks_button = new System.Windows.Forms.Button();
            this.deletebook_button = new System.Windows.Forms.Button();
            this.addbook_button = new System.Windows.Forms.Button();
            this.bookgridview2 = new System.Windows.Forms.DataGridView();
            this.displaybookloan_button = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.bookgridview)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookgridview2)).BeginInit();
            this.SuspendLayout();
            // 
            // displaycategory_button
            // 
            this.displaycategory_button.BackColor = System.Drawing.Color.LightPink;
            this.displaycategory_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displaycategory_button.Location = new System.Drawing.Point(47, 368);
            this.displaycategory_button.Name = "displaycategory_button";
            this.displaycategory_button.Size = new System.Drawing.Size(172, 49);
            this.displaycategory_button.TabIndex = 17;
            this.displaycategory_button.Text = "Display Category";
            this.displaycategory_button.UseVisualStyleBackColor = false;
            this.displaycategory_button.Click += new System.EventHandler(this.displaycategory_button_Click);
            // 
            // bookloan_button
            // 
            this.bookloan_button.BackColor = System.Drawing.Color.LightPink;
            this.bookloan_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookloan_button.Location = new System.Drawing.Point(47, 232);
            this.bookloan_button.Name = "bookloan_button";
            this.bookloan_button.Size = new System.Drawing.Size(172, 49);
            this.bookloan_button.TabIndex = 16;
            this.bookloan_button.Text = "Issue Book ";
            this.bookloan_button.UseVisualStyleBackColor = false;
            this.bookloan_button.Click += new System.EventHandler(this.bookloan_button_Click);
            // 
            // bookgridview
            // 
            this.bookgridview.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.bookgridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bookgridview.GridColor = System.Drawing.SystemColors.ControlLightLight;
            this.bookgridview.Location = new System.Drawing.Point(261, 22);
            this.bookgridview.Name = "bookgridview";
            this.bookgridview.Size = new System.Drawing.Size(506, 297);
            this.bookgridview.TabIndex = 15;
            // 
            // displaybooks_button
            // 
            this.displaybooks_button.BackColor = System.Drawing.Color.LightPink;
            this.displaybooks_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displaybooks_button.Location = new System.Drawing.Point(47, 22);
            this.displaybooks_button.Name = "displaybooks_button";
            this.displaybooks_button.Size = new System.Drawing.Size(172, 54);
            this.displaybooks_button.TabIndex = 14;
            this.displaybooks_button.Text = "Display Books";
            this.displaybooks_button.UseVisualStyleBackColor = false;
            this.displaybooks_button.Click += new System.EventHandler(this.displaybooks_button_Click);
            // 
            // deletebook_button
            // 
            this.deletebook_button.BackColor = System.Drawing.Color.LightPink;
            this.deletebook_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deletebook_button.Location = new System.Drawing.Point(47, 162);
            this.deletebook_button.Name = "deletebook_button";
            this.deletebook_button.Size = new System.Drawing.Size(172, 49);
            this.deletebook_button.TabIndex = 13;
            this.deletebook_button.Text = "Delete Book";
            this.deletebook_button.UseVisualStyleBackColor = false;
            this.deletebook_button.Click += new System.EventHandler(this.deletebook_button_Click);
            // 
            // addbook_button
            // 
            this.addbook_button.BackColor = System.Drawing.Color.LightPink;
            this.addbook_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addbook_button.Location = new System.Drawing.Point(47, 94);
            this.addbook_button.Name = "addbook_button";
            this.addbook_button.Size = new System.Drawing.Size(172, 53);
            this.addbook_button.TabIndex = 12;
            this.addbook_button.Text = "Add Book";
            this.addbook_button.UseVisualStyleBackColor = false;
            this.addbook_button.Click += new System.EventHandler(this.addbook_button_Click);
            // 
            // bookgridview2
            // 
            this.bookgridview2.BackgroundColor = System.Drawing.SystemColors.Control;
            this.bookgridview2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bookgridview2.Location = new System.Drawing.Point(261, 351);
            this.bookgridview2.Name = "bookgridview2";
            this.bookgridview2.Size = new System.Drawing.Size(240, 66);
            this.bookgridview2.TabIndex = 18;
            // 
            // displaybookloan_button
            // 
            this.displaybookloan_button.BackColor = System.Drawing.Color.LightPink;
            this.displaybookloan_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displaybookloan_button.Location = new System.Drawing.Point(47, 300);
            this.displaybookloan_button.Name = "displaybookloan_button";
            this.displaybookloan_button.Size = new System.Drawing.Size(172, 49);
            this.displaybookloan_button.TabIndex = 19;
            this.displaybookloan_button.Text = "Display Book Loan";
            this.displaybookloan_button.UseVisualStyleBackColor = false;
            this.displaybookloan_button.Click += new System.EventHandler(this.button1_Click);
            // 
            // Books
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.displaybookloan_button);
            this.Controls.Add(this.bookgridview2);
            this.Controls.Add(this.displaycategory_button);
            this.Controls.Add(this.bookloan_button);
            this.Controls.Add(this.bookgridview);
            this.Controls.Add(this.displaybooks_button);
            this.Controls.Add(this.deletebook_button);
            this.Controls.Add(this.addbook_button);
            this.Name = "Books";
            this.Text = "Books";
            ((System.ComponentModel.ISupportInitialize)(this.bookgridview)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookgridview2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button displaycategory_button;
        private System.Windows.Forms.Button bookloan_button;
        private System.Windows.Forms.DataGridView bookgridview;
        private System.Windows.Forms.Button displaybooks_button;
        private System.Windows.Forms.Button deletebook_button;
        private System.Windows.Forms.Button addbook_button;
        private System.Windows.Forms.DataGridView bookgridview2;
        private System.Windows.Forms.Button displaybookloan_button;
    }
}