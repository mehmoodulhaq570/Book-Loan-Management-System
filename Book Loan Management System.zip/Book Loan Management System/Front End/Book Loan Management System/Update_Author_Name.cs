﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Book_Loan_Management_System
{
    public partial class Update_Author_Name : Form
    {
        public Update_Author_Name()
        {
            InitializeComponent();
        }

        private void Update_Author_Name_Load(object sender, EventArgs e)
        {
            try
            {
                // Use the provided username and password from Login_Form
                var thisUsername = Login_Form.username;
                var thisPassword = Login_Form.password;

                // Connection string with user credentials
                string connString = @"Data Source=(local)\SQLEXPRESS; Initial Catalog=Book Loan System; User ID=" + thisUsername + "; Password=" + thisPassword + ";";

                using (SqlConnection connection = new SqlConnection(connString))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand())
                    {
                        command.Connection = connection;

                        // Use parameters to prevent SQL injection
                        command.CommandText = "UPDATE Author SET first_name = @FirstName, last_name = @LastName WHERE author_id = @AuthorID;";

                        // Assuming authorId is the author_id you want to update, firstName is the new first name, and lastName is the new last name
                        command.Parameters.AddWithValue("@AuthorID", authorid_textbox);
                        command.Parameters.AddWithValue("@FirstName", firstname_textbox);
                        command.Parameters.AddWithValue("@LastName", lastname_textbox);

                        command.ExecuteNonQuery();
                    }

                    MessageBox.Show("Author Name Updated!!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }
    }
}
