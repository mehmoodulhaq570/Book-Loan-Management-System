﻿namespace Book_Loan_Management_System
{
    partial class Add_Borrower
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.address_textbox = new System.Windows.Forms.TextBox();
            this.contactno_textbox = new System.Windows.Forms.TextBox();
            this.emailid_textbox = new System.Windows.Forms.TextBox();
            this.lastname_textbox = new System.Windows.Forms.TextBox();
            this.firstname_textbox = new System.Windows.Forms.TextBox();
            this.borrowerid_textbox = new System.Windows.Forms.TextBox();
            this.address_label = new System.Windows.Forms.Label();
            this.emailid_label = new System.Windows.Forms.Label();
            this.contactno_label = new System.Windows.Forms.Label();
            this.lastname_label = new System.Windows.Forms.Label();
            this.firstname_label = new System.Windows.Forms.Label();
            this.borrowerid_label = new System.Windows.Forms.Label();
            this.addborrower_button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // address_textbox
            // 
            this.address_textbox.Location = new System.Drawing.Point(328, 265);
            this.address_textbox.Name = "address_textbox";
            this.address_textbox.Size = new System.Drawing.Size(100, 20);
            this.address_textbox.TabIndex = 30;
            // 
            // contactno_textbox
            // 
            this.contactno_textbox.Location = new System.Drawing.Point(328, 225);
            this.contactno_textbox.Name = "contactno_textbox";
            this.contactno_textbox.Size = new System.Drawing.Size(100, 20);
            this.contactno_textbox.TabIndex = 29;
            // 
            // emailid_textbox
            // 
            this.emailid_textbox.Location = new System.Drawing.Point(328, 189);
            this.emailid_textbox.Name = "emailid_textbox";
            this.emailid_textbox.Size = new System.Drawing.Size(100, 20);
            this.emailid_textbox.TabIndex = 28;
            // 
            // lastname_textbox
            // 
            this.lastname_textbox.Location = new System.Drawing.Point(328, 150);
            this.lastname_textbox.Name = "lastname_textbox";
            this.lastname_textbox.Size = new System.Drawing.Size(100, 20);
            this.lastname_textbox.TabIndex = 27;
            // 
            // firstname_textbox
            // 
            this.firstname_textbox.Location = new System.Drawing.Point(328, 105);
            this.firstname_textbox.Name = "firstname_textbox";
            this.firstname_textbox.Size = new System.Drawing.Size(100, 20);
            this.firstname_textbox.TabIndex = 26;
            // 
            // borrowerid_textbox
            // 
            this.borrowerid_textbox.Location = new System.Drawing.Point(328, 64);
            this.borrowerid_textbox.Name = "borrowerid_textbox";
            this.borrowerid_textbox.Size = new System.Drawing.Size(100, 20);
            this.borrowerid_textbox.TabIndex = 25;
            // 
            // address_label
            // 
            this.address_label.AutoSize = true;
            this.address_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.address_label.Location = new System.Drawing.Point(122, 265);
            this.address_label.Name = "address_label";
            this.address_label.Size = new System.Drawing.Size(68, 20);
            this.address_label.TabIndex = 22;
            this.address_label.Text = "Address";
            // 
            // emailid_label
            // 
            this.emailid_label.AutoSize = true;
            this.emailid_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailid_label.Location = new System.Drawing.Point(122, 187);
            this.emailid_label.Name = "emailid_label";
            this.emailid_label.Size = new System.Drawing.Size(71, 20);
            this.emailid_label.TabIndex = 21;
            this.emailid_label.Text = "Email_Id";
            // 
            // contactno_label
            // 
            this.contactno_label.AutoSize = true;
            this.contactno_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contactno_label.Location = new System.Drawing.Point(122, 225);
            this.contactno_label.Name = "contactno_label";
            this.contactno_label.Size = new System.Drawing.Size(94, 20);
            this.contactno_label.TabIndex = 20;
            this.contactno_label.Text = "Contact_No";
            // 
            // lastname_label
            // 
            this.lastname_label.AutoSize = true;
            this.lastname_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastname_label.Location = new System.Drawing.Point(122, 148);
            this.lastname_label.Name = "lastname_label";
            this.lastname_label.Size = new System.Drawing.Size(89, 20);
            this.lastname_label.TabIndex = 19;
            this.lastname_label.Text = "Last_name";
            // 
            // firstname_label
            // 
            this.firstname_label.AutoSize = true;
            this.firstname_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstname_label.Location = new System.Drawing.Point(122, 105);
            this.firstname_label.Name = "firstname_label";
            this.firstname_label.Size = new System.Drawing.Size(89, 20);
            this.firstname_label.TabIndex = 18;
            this.firstname_label.Text = "First_name";
            // 
            // borrowerid_label
            // 
            this.borrowerid_label.AutoSize = true;
            this.borrowerid_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.borrowerid_label.Location = new System.Drawing.Point(122, 65);
            this.borrowerid_label.Name = "borrowerid_label";
            this.borrowerid_label.Size = new System.Drawing.Size(94, 20);
            this.borrowerid_label.TabIndex = 17;
            this.borrowerid_label.Text = "Borrower_id";
            // 
            // addborrower_button
            // 
            this.addborrower_button.BackColor = System.Drawing.Color.LightPink;
            this.addborrower_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addborrower_button.Location = new System.Drawing.Point(187, 326);
            this.addborrower_button.Name = "addborrower_button";
            this.addborrower_button.Size = new System.Drawing.Size(172, 47);
            this.addborrower_button.TabIndex = 33;
            this.addborrower_button.Text = "Add Borrower";
            this.addborrower_button.UseVisualStyleBackColor = false;
            this.addborrower_button.Click += new System.EventHandler(this.addborrower_button_Click);
            // 
            // Add_Borrower
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(681, 450);
            this.Controls.Add(this.addborrower_button);
            this.Controls.Add(this.address_textbox);
            this.Controls.Add(this.contactno_textbox);
            this.Controls.Add(this.emailid_textbox);
            this.Controls.Add(this.lastname_textbox);
            this.Controls.Add(this.firstname_textbox);
            this.Controls.Add(this.borrowerid_textbox);
            this.Controls.Add(this.address_label);
            this.Controls.Add(this.emailid_label);
            this.Controls.Add(this.contactno_label);
            this.Controls.Add(this.lastname_label);
            this.Controls.Add(this.firstname_label);
            this.Controls.Add(this.borrowerid_label);
            this.Name = "Add_Borrower";
            this.Text = "Add_Borrower";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox address_textbox;
        private System.Windows.Forms.TextBox contactno_textbox;
        private System.Windows.Forms.TextBox emailid_textbox;
        private System.Windows.Forms.TextBox lastname_textbox;
        private System.Windows.Forms.TextBox firstname_textbox;
        private System.Windows.Forms.TextBox borrowerid_textbox;
        private System.Windows.Forms.Label address_label;
        private System.Windows.Forms.Label emailid_label;
        private System.Windows.Forms.Label contactno_label;
        private System.Windows.Forms.Label lastname_label;
        private System.Windows.Forms.Label firstname_label;
        private System.Windows.Forms.Label borrowerid_label;
        private System.Windows.Forms.Button addborrower_button;
    }
}