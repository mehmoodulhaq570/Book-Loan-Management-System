﻿namespace Book_Loan_Management_System
{
    partial class Add_Authos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.authorid_label = new System.Windows.Forms.Label();
            this.firstname_label = new System.Windows.Forms.Label();
            this.lastname_label = new System.Windows.Forms.Label();
            this.contactno_label = new System.Windows.Forms.Label();
            this.emailid_label = new System.Windows.Forms.Label();
            this.address_label = new System.Windows.Forms.Label();
            this.fileSystemWatcher1 = new System.IO.FileSystemWatcher();
            this.dateofbirth_label = new System.Windows.Forms.Label();
            this.nationalty_label = new System.Windows.Forms.Label();
            this.authorid_textbox = new System.Windows.Forms.TextBox();
            this.firstname_textbox = new System.Windows.Forms.TextBox();
            this.lastname_textbox = new System.Windows.Forms.TextBox();
            this.emailid_textbox = new System.Windows.Forms.TextBox();
            this.contactno_textbox = new System.Windows.Forms.TextBox();
            this.address_textbox = new System.Windows.Forms.TextBox();
            this.dateofbirth_textbox = new System.Windows.Forms.TextBox();
            this.nationality_textbox = new System.Windows.Forms.TextBox();
            this.addauthor_button = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).BeginInit();
            this.SuspendLayout();
            // 
            // authorid_label
            // 
            this.authorid_label.AutoSize = true;
            this.authorid_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.authorid_label.Location = new System.Drawing.Point(131, 58);
            this.authorid_label.Name = "authorid_label";
            this.authorid_label.Size = new System.Drawing.Size(78, 20);
            this.authorid_label.TabIndex = 0;
            this.authorid_label.Text = "Author_id";
            this.authorid_label.Click += new System.EventHandler(this.label1_Click);
            // 
            // firstname_label
            // 
            this.firstname_label.AutoSize = true;
            this.firstname_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstname_label.Location = new System.Drawing.Point(131, 98);
            this.firstname_label.Name = "firstname_label";
            this.firstname_label.Size = new System.Drawing.Size(89, 20);
            this.firstname_label.TabIndex = 1;
            this.firstname_label.Text = "First_name";
            // 
            // lastname_label
            // 
            this.lastname_label.AutoSize = true;
            this.lastname_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastname_label.Location = new System.Drawing.Point(131, 141);
            this.lastname_label.Name = "lastname_label";
            this.lastname_label.Size = new System.Drawing.Size(89, 20);
            this.lastname_label.TabIndex = 2;
            this.lastname_label.Text = "Last_name";
            // 
            // contactno_label
            // 
            this.contactno_label.AutoSize = true;
            this.contactno_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contactno_label.Location = new System.Drawing.Point(131, 218);
            this.contactno_label.Name = "contactno_label";
            this.contactno_label.Size = new System.Drawing.Size(94, 20);
            this.contactno_label.TabIndex = 3;
            this.contactno_label.Text = "Contact_No";
            // 
            // emailid_label
            // 
            this.emailid_label.AutoSize = true;
            this.emailid_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailid_label.Location = new System.Drawing.Point(131, 180);
            this.emailid_label.Name = "emailid_label";
            this.emailid_label.Size = new System.Drawing.Size(71, 20);
            this.emailid_label.TabIndex = 4;
            this.emailid_label.Text = "Email_Id";
            this.emailid_label.Click += new System.EventHandler(this.label4_Click);
            // 
            // address_label
            // 
            this.address_label.AutoSize = true;
            this.address_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.address_label.Location = new System.Drawing.Point(131, 258);
            this.address_label.Name = "address_label";
            this.address_label.Size = new System.Drawing.Size(68, 20);
            this.address_label.TabIndex = 5;
            this.address_label.Text = "Address";
            // 
            // fileSystemWatcher1
            // 
            this.fileSystemWatcher1.EnableRaisingEvents = true;
            this.fileSystemWatcher1.SynchronizingObject = this;
            // 
            // dateofbirth_label
            // 
            this.dateofbirth_label.AutoSize = true;
            this.dateofbirth_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateofbirth_label.Location = new System.Drawing.Point(131, 298);
            this.dateofbirth_label.Name = "dateofbirth_label";
            this.dateofbirth_label.Size = new System.Drawing.Size(107, 20);
            this.dateofbirth_label.TabIndex = 6;
            this.dateofbirth_label.Text = "Date_of_birth";
            this.dateofbirth_label.Click += new System.EventHandler(this.dateofbirth_label_Click);
            // 
            // nationalty_label
            // 
            this.nationalty_label.AutoSize = true;
            this.nationalty_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nationalty_label.Location = new System.Drawing.Point(131, 342);
            this.nationalty_label.Name = "nationalty_label";
            this.nationalty_label.Size = new System.Drawing.Size(82, 20);
            this.nationalty_label.TabIndex = 7;
            this.nationalty_label.Text = "Nationality";
            // 
            // authorid_textbox
            // 
            this.authorid_textbox.Location = new System.Drawing.Point(337, 57);
            this.authorid_textbox.Name = "authorid_textbox";
            this.authorid_textbox.Size = new System.Drawing.Size(100, 20);
            this.authorid_textbox.TabIndex = 8;
            // 
            // firstname_textbox
            // 
            this.firstname_textbox.Location = new System.Drawing.Point(337, 98);
            this.firstname_textbox.Name = "firstname_textbox";
            this.firstname_textbox.Size = new System.Drawing.Size(100, 20);
            this.firstname_textbox.TabIndex = 9;
            // 
            // lastname_textbox
            // 
            this.lastname_textbox.Location = new System.Drawing.Point(337, 143);
            this.lastname_textbox.Name = "lastname_textbox";
            this.lastname_textbox.Size = new System.Drawing.Size(100, 20);
            this.lastname_textbox.TabIndex = 10;
            // 
            // emailid_textbox
            // 
            this.emailid_textbox.Location = new System.Drawing.Point(337, 182);
            this.emailid_textbox.Name = "emailid_textbox";
            this.emailid_textbox.Size = new System.Drawing.Size(100, 20);
            this.emailid_textbox.TabIndex = 11;
            // 
            // contactno_textbox
            // 
            this.contactno_textbox.Location = new System.Drawing.Point(337, 218);
            this.contactno_textbox.Name = "contactno_textbox";
            this.contactno_textbox.Size = new System.Drawing.Size(100, 20);
            this.contactno_textbox.TabIndex = 12;
            // 
            // address_textbox
            // 
            this.address_textbox.Location = new System.Drawing.Point(337, 258);
            this.address_textbox.Name = "address_textbox";
            this.address_textbox.Size = new System.Drawing.Size(100, 20);
            this.address_textbox.TabIndex = 13;
            // 
            // dateofbirth_textbox
            // 
            this.dateofbirth_textbox.Location = new System.Drawing.Point(337, 298);
            this.dateofbirth_textbox.Name = "dateofbirth_textbox";
            this.dateofbirth_textbox.Size = new System.Drawing.Size(100, 20);
            this.dateofbirth_textbox.TabIndex = 14;
            // 
            // nationality_textbox
            // 
            this.nationality_textbox.Location = new System.Drawing.Point(337, 344);
            this.nationality_textbox.Name = "nationality_textbox";
            this.nationality_textbox.Size = new System.Drawing.Size(100, 20);
            this.nationality_textbox.TabIndex = 15;
            // 
            // addauthor_button
            // 
            this.addauthor_button.BackColor = System.Drawing.Color.LightPink;
            this.addauthor_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addauthor_button.Location = new System.Drawing.Point(511, 180);
            this.addauthor_button.Name = "addauthor_button";
            this.addauthor_button.Size = new System.Drawing.Size(150, 43);
            this.addauthor_button.TabIndex = 16;
            this.addauthor_button.Text = "Add Author";
            this.addauthor_button.UseVisualStyleBackColor = false;
            this.addauthor_button.Click += new System.EventHandler(this.addauthor_button_Click);
            // 
            // Add_Authos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(735, 463);
            this.Controls.Add(this.addauthor_button);
            this.Controls.Add(this.nationality_textbox);
            this.Controls.Add(this.dateofbirth_textbox);
            this.Controls.Add(this.address_textbox);
            this.Controls.Add(this.contactno_textbox);
            this.Controls.Add(this.emailid_textbox);
            this.Controls.Add(this.lastname_textbox);
            this.Controls.Add(this.firstname_textbox);
            this.Controls.Add(this.authorid_textbox);
            this.Controls.Add(this.nationalty_label);
            this.Controls.Add(this.dateofbirth_label);
            this.Controls.Add(this.address_label);
            this.Controls.Add(this.emailid_label);
            this.Controls.Add(this.contactno_label);
            this.Controls.Add(this.lastname_label);
            this.Controls.Add(this.firstname_label);
            this.Controls.Add(this.authorid_label);
            this.Name = "Add_Authos";
            this.Text = "Add_Authos";
            this.Load += new System.EventHandler(this.Add_Authos_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label authorid_label;
        private System.Windows.Forms.Label firstname_label;
        private System.Windows.Forms.Label lastname_label;
        private System.Windows.Forms.Label contactno_label;
        private System.Windows.Forms.Label emailid_label;
        private System.Windows.Forms.Label address_label;
        private System.IO.FileSystemWatcher fileSystemWatcher1;
        private System.Windows.Forms.Label dateofbirth_label;
        private System.Windows.Forms.TextBox dateofbirth_textbox;
        private System.Windows.Forms.TextBox address_textbox;
        private System.Windows.Forms.TextBox contactno_textbox;
        private System.Windows.Forms.TextBox emailid_textbox;
        private System.Windows.Forms.TextBox lastname_textbox;
        private System.Windows.Forms.TextBox firstname_textbox;
        private System.Windows.Forms.TextBox authorid_textbox;
        private System.Windows.Forms.Label nationalty_label;
        private System.Windows.Forms.TextBox nationality_textbox;
        private System.Windows.Forms.Button addauthor_button;
    }
}